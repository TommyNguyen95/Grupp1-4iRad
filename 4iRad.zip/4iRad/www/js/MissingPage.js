class MissingPage extends Component {

  constructor(){
    super();
    this.addRoute('404', 'Missing page');
  }

}