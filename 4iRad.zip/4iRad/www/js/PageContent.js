class PageContent extends Component {

  constructor(){
    super();
    this.startPage = new StartPage();
    this.aboutPage = new AboutPage();
    this.missingPage = new MissingPage();
  }
  
}