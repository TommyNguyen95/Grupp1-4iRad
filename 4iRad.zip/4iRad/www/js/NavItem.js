class NavItem extends Component {

  constructor(name, url){
    super();
    this.name = name;
    this.url = url;
  }

}